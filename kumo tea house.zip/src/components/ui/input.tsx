import * as React from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-lg bg-surface px-3.5 text-sm text-foreground shadow-[var(--shadow-border)]",
        "placeholder:text-subtle transition-[box-shadow] duration-(--motion-quick)",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "min-h-28 w-full rounded-lg bg-surface px-3.5 py-3 text-sm text-foreground shadow-[var(--shadow-border)]",
        "placeholder:text-subtle transition-[box-shadow] duration-(--motion-quick)",
        "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
        className,
      )}
      {...props}
    />
  );
}
