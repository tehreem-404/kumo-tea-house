import { Link } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

const LINKS = [
  { to: "/collection", label: "Collection" },
  { to: "/ceremony", label: "Ceremony" },
  { to: "/journal", label: "Journal" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    void useFavorites.persist.rehydrate();
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
        <Link to="/" className="font-display text-lg tracking-tight text-foreground">
          Kumo
        </Link>
        <nav className="hidden items-center gap-8 md:flex">
          {LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="text-sm text-muted transition-colors duration-150 hover:text-foreground"
              activeProps={{ className: "text-foreground" }}
            >
              {link.label}
            </Link>
          ))}
          <Button asChild size="sm">
            <Link to="/ceremony">Reserve a seat</Link>
          </Button>
        </nav>
        <button
          type="button"
          className="relative flex size-11 items-center justify-center rounded-lg md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
      </div>
      <div
        className={cn(
          "border-t border-border bg-bg px-5 py-4 md:hidden",
          open ? "block" : "hidden",
        )}
      >
        <nav className="flex flex-col gap-1">
          {LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="flex h-11 items-center text-sm text-foreground"
              onClick={() => setOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <Button asChild className="mt-2 w-full">
            <Link to="/ceremony" onClick={() => setOpen(false)}>
              Reserve a seat
            </Link>
          </Button>
        </nav>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex max-w-6xl flex-col gap-6 px-5 py-12 sm:flex-row sm:items-end sm:justify-between sm:px-8">
        <div>
          <p className="font-display text-lg text-foreground">Kumo Tea House</p>
          <p className="mt-2 max-w-sm text-sm text-muted">
            A small room for tea on Franklin Street. Leaves from Uji, Yame, Alishan, and Fuding.
          </p>
        </div>
        <p className="text-sm text-subtle">Open daily, 11–7 · 18 Franklin St</p>
      </div>
    </footer>
  );
}
