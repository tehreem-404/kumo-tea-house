import { Link } from "@tanstack/react-router";
import { Heart } from "lucide-react";
import { KIND_LABEL, type Tea } from "@/lib/catalog";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

export function TeaCard({ tea }: { tea: Tea }) {
  const has = useFavorites((s) => s.ids.includes(tea.id));
  const toggle = useFavorites((s) => s.toggle);

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-250 hover:shadow-[var(--shadow-border-hover)]">
      <Link to="/collection/$id" params={{ id: tea.id }} className="relative block aspect-square overflow-hidden">
        <img
          src={tea.image}
          alt={tea.name}
          className="size-full object-cover transition-transform duration-400 group-hover:scale-[1.03]"
        />
      </Link>
      <div className="flex flex-1 flex-col gap-2 p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-xs font-medium uppercase tracking-wider text-subtle">
              {KIND_LABEL[tea.kind]} · {tea.origin}
            </p>
            <h3 className="mt-1 font-display text-xl text-foreground">
              <Link to="/collection/$id" params={{ id: tea.id }}>
                {tea.name}
              </Link>
            </h3>
          </div>
          <button
            type="button"
            aria-label={has ? "Remove from cellar" : "Save to cellar"}
            aria-pressed={has}
            className="relative flex size-11 shrink-0 items-center justify-center rounded-lg"
            onClick={() => toggle(tea.id)}
          >
            <Heart
              className={cn("size-5", has ? "fill-primary text-primary" : "text-muted")}
            />
          </button>
        </div>
        <p className="text-sm text-muted">{tea.notes}</p>
        <p className="mt-auto pt-2 text-sm tabular-nums text-foreground">${tea.price}</p>
      </div>
    </article>
  );
}
