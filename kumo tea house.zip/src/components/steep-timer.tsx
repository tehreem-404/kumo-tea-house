import { Pause, Play, RotateCcw } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

export function SteepTimer({ minutes }: { minutes: number }) {
  const total = Math.max(1, Math.round(minutes * 60));
  const [left, setLeft] = useState(total);
  const [running, setRunning] = useState(false);

  useEffect(() => {
    setLeft(total);
    setRunning(false);
  }, [total]);

  useEffect(() => {
    if (!running) return;
    const id = window.setInterval(() => {
      setLeft((s) => {
        if (s <= 1) {
          setRunning(false);
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [running]);

  const m = Math.floor(left / 60);
  const s = left % 60;

  return (
    <div className="flex flex-wrap items-center gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]">
      <p className="font-display text-3xl tabular-nums tracking-tight text-foreground">
        {m}:{s.toString().padStart(2, "0")}
      </p>
      <div className="flex gap-2">
        <Button
          size="sm"
          variant={running ? "outline" : "default"}
          onClick={() => setRunning((v) => !v)}
          disabled={left === 0 && !running}
        >
          {running ? <Pause className="size-4" /> : <Play className="size-4" />}
          {running ? "Pause" : "Steep"}
        </Button>
        <Button
          size="sm"
          variant="ghost"
          onClick={() => {
            setLeft(total);
            setRunning(false);
          }}
        >
          <RotateCcw className="size-4" />
          Reset
        </Button>
      </div>
    </div>
  );
}
