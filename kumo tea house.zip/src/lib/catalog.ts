export type TeaKind = "green" | "oxidized" | "roasted" | "powder";

export type Tea = {
  id: string;
  name: string;
  origin: string;
  kind: TeaKind;
  harvest: string;
  steepC: number;
  steepMin: number;
  price: number;
  image: string;
  notes: string;
  featured?: boolean;
};

export const KIND_LABEL: Record<TeaKind, string> = {
  green: "Green",
  oxidized: "Oxidized",
  roasted: "Roasted",
  powder: "Powder",
};

export const TEAS: Tea[] = [
  {
    id: "gyokuro",
    name: "Uji Gyokuro",
    origin: "Uji, Kyoto",
    kind: "green",
    harvest: "First flush, April",
    steepC: 55,
    steepMin: 2,
    price: 48,
    image: "/images/gyokuro.jpg",
    notes: "Shade-grown for three weeks. Broth of steamed spinach, sweet pea, and ocean air.",
    featured: true,
  },
  {
    id: "sencha",
    name: "Yame Asamushi",
    origin: "Yame, Fukuoka",
    kind: "green",
    harvest: "Spring, May",
    steepC: 75,
    steepMin: 1,
    price: 28,
    image: "/images/sencha.jpg",
    notes: "Light steam, bright liquor. Cut grass, yuzu zest, and a clean mineral finish.",
    featured: true,
  },
  {
    id: "matcha",
    name: "Ceremonial Matcha",
    origin: "Nishio, Aichi",
    kind: "powder",
    harvest: "Tencha, April",
    steepC: 75,
    steepMin: 0,
    price: 56,
    image: "/images/matcha.jpg",
    notes: "Stone-milled tencha. Velvet foam, pistachio, and a lingering sweetness.",
    featured: true,
  },
  {
    id: "oolong",
    name: "Ali Shan Oolong",
    origin: "Alishan, Taiwan",
    kind: "oxidized",
    harvest: "Winter, December",
    steepC: 90,
    steepMin: 3,
    price: 42,
    image: "/images/oolong.jpg",
    notes: "High-mountain pearls. Orchid, cream, and a long honeyed aftertaste.",
  },
  {
    id: "hojicha",
    name: "Kyoto Hojicha",
    origin: "Wazuka, Kyoto",
    kind: "roasted",
    harvest: "Autumn, October",
    steepC: 90,
    steepMin: 1,
    price: 22,
    image: "/images/hojicha.jpg",
    notes: "Twigs and leaves roasted over charcoal. Toasted rice, cocoa husk, evening warmth.",
  },
  {
    id: "white-peony",
    name: "Bai Mu Dan",
    origin: "Fuding, Fujian",
    kind: "oxidized",
    harvest: "Spring, March",
    steepC: 85,
    steepMin: 4,
    price: 34,
    image: "/images/white-peony.jpg",
    notes: "Buds and young leaves. Dried hay, apricot skin, and a silk-soft liquor.",
  },
];

export const JOURNAL = [
  {
    slug: "first-flush",
    title: "On waiting for the first flush",
    date: "March 12, 2026",
    excerpt:
      "Shade cloths go up in Uji three weeks before harvest. The garden goes quiet. What follows is not haste — it is a held breath.",
    body: `The first flush is less a date than a negotiation with weather. In Uji the cloths are raised when the new leaves are still tightly furled, and for twenty-one days the garden lives in a kind of twilight. Chlorophyll thickens. Amino acids concentrate. The plant, denied full sun, begins to taste of the sea.

We buy only from families who still shade by hand. Machine cloth is faster, but it does not listen. The difference is in the cup: a broth that is sweet before it is bitter, that cools into pea and nori rather than grass.

If you steep gyokuro above 60°C you will miss this. The kettle should barely whisper. Two minutes. Then a second infusion, thirty seconds shorter, that tastes like the first’s quieter sibling.`,
  },
  {
    slug: "water",
    title: "Water is half the tea",
    date: "January 4, 2026",
    excerpt:
      "Soft water, just off the boil, poured from a height for sencha and from the lip for gyokuro. The leaf is already decided; the water is the last edit.",
    body: `Most disappointing cups are not the tea’s fault. They are water that was too hard, too hot, or left standing until it tasted of the kettle.

We keep a simple charcoal filter on the house line and reboil only once. For green teas, cool the water in an open pitcher until the steam thins. For roasted leaves, the kettle can be louder.

If you live where the tap is mineral-heavy, blend with a splash of distilled water. You are not purifying the tea — you are giving it room to speak.`,
  },
  {
    slug: "ceremony",
    title: "A room with one job",
    date: "November 18, 2025",
    excerpt:
      "The tearoom on Franklin is eight tatami and a window onto a courtyard maple. Nothing else is asked of it.",
    body: `We built the room to be empty on purpose. A hanging lantern, a low table, paper screens that leak afternoon light. Guests leave phones in a cedar box at the door — not as a rule of piety, but so the hour can have edges.

A seating is forty minutes. You will not learn the full way of tea. You will learn how long a minute can be when it is filled with steam and not with errands.

Reservations open on the first of each month. Walk-ins are welcome for counter steeping in the front room, where the kettles never quite rest.`,
  },
];
