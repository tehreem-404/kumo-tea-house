import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";

export const Route = createFileRoute("/ceremony")({ component: CeremonyPage });

const SEATINGS = ["Thursday 4:00", "Friday 4:00", "Saturday 11:00", "Saturday 3:00", "Sunday 11:00"];

function CeremonyPage() {
  const [sent, setSent] = useState(false);
  const [name, setName] = useState("");

  function onSubmit(e: FormEvent) {
    e.preventDefault();
    setSent(true);
  }

  return (
    <main className="mx-auto grid max-w-6xl gap-12 px-5 py-14 lg:grid-cols-2 lg:items-start sm:px-8">
      <div>
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">Reservations</p>
        <h1 className="mt-2 font-display text-4xl text-foreground">Sit for tea</h1>
        <p className="mt-4 text-muted">
          Forty minutes in the back room. Six seats. We steep the day’s gyokuro or matcha, then a quieter roasted
          cup to close. Leave the phone in the box at the door.
        </p>
        <img
          src="/images/ceremony.jpg"
          alt="Hands pouring tea from a kyusu"
          className="mt-8 aspect-[4/3] w-full rounded-2xl object-cover"
        />
      </div>

      <div className="rounded-2xl bg-surface p-6 shadow-[var(--shadow-border)] sm:p-8">
        {sent ? (
          <div>
            <h2 className="font-display text-2xl text-foreground">We have your name.</h2>
            <p className="mt-3 text-sm text-muted">
              Thank you{name ? `, ${name}` : ""}. This is a house request, not a confirmed booking — we write back
              within a day with a seat or a waitlist place.
            </p>
            <Button className="mt-8" variant="outline" onClick={() => setSent(false)}>
              Send another request
            </Button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="flex flex-col gap-5">
            <h2 className="font-display text-2xl text-foreground">Request a seating</h2>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Name</span>
              <Input
                required
                name="name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
              />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Email</span>
              <Input required type="email" name="email" autoComplete="email" />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Preferred seating</span>
              <select
                name="seating"
                className="h-11 w-full rounded-lg bg-bg px-3.5 text-sm text-foreground shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                defaultValue={SEATINGS[0]}
              >
                {SEATINGS.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Guests</span>
              <Input required type="number" name="guests" min={1} max={6} defaultValue={2} />
            </label>
            <label className="block text-sm">
              <span className="mb-1.5 block text-muted">Notes</span>
              <Textarea name="notes" placeholder="Allergies, celebration, first visit…" />
            </label>
            <Button type="submit" className="w-full">
              Request seating
            </Button>
            <p className="text-xs text-subtle">We keep this request on your device only. No account required.</p>
          </form>
        )}
      </div>
    </main>
  );
}
