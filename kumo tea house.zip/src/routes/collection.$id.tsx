import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, Heart } from "lucide-react";
import { SteepTimer } from "@/components/steep-timer";
import { Button } from "@/components/ui/button";
import { KIND_LABEL, TEAS } from "@/lib/catalog";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/collection/$id")({
  component: TeaDetail,
  loader: ({ params }) => {
    const tea = TEAS.find((t) => t.id === params.id);
    if (!tea) throw notFound();
    return { tea };
  },
});

function TeaDetail() {
  const { tea } = Route.useLoaderData();
  const has = useFavorites((s) => s.ids.includes(tea.id));
  const toggle = useFavorites((s) => s.toggle);

  return (
    <main className="mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-2 lg:items-start sm:px-8">
      <img
        src={tea.image}
        alt={tea.name}
        className="aspect-square w-full rounded-2xl object-cover"
      />
      <div>
        <Link
          to="/collection"
          className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          Collection
        </Link>
        <p className="mt-6 text-xs font-medium uppercase tracking-[0.2em] text-subtle">
          {KIND_LABEL[tea.kind]} · {tea.origin}
        </p>
        <h1 className="mt-2 font-display text-4xl text-foreground">{tea.name}</h1>
        <p className="mt-4 text-base text-muted">{tea.notes}</p>

        <dl className="mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3">
          <div>
            <dt className="text-subtle">Harvest</dt>
            <dd className="mt-1 text-foreground">{tea.harvest}</dd>
          </div>
          <div>
            <dt className="text-subtle">Water</dt>
            <dd className="mt-1 tabular-nums text-foreground">{tea.steepC}°C</dd>
          </div>
          <div>
            <dt className="text-subtle">Time</dt>
            <dd className="mt-1 tabular-nums text-foreground">
              {tea.steepMin === 0 ? "Whisk" : `${tea.steepMin} min`}
            </dd>
          </div>
        </dl>

        <p className="mt-6 font-display text-2xl tabular-nums text-foreground">${tea.price}</p>

        <div className="mt-6 flex flex-wrap gap-3">
          <Button
            variant={has ? "outline" : "default"}
            onClick={() => toggle(tea.id)}
          >
            <Heart className={cn("size-4", has && "fill-current")} />
            {has ? "In your cellar" : "Save to cellar"}
          </Button>
        </div>

        {tea.steepMin > 0 ? (
          <div className="mt-10">
            <h2 className="font-display text-xl text-foreground">Steep timer</h2>
            <p className="mt-1 mb-4 text-sm text-muted">
              Set for the first infusion. Reset between cups.
            </p>
            <SteepTimer minutes={tea.steepMin} />
          </div>
        ) : (
          <p className="mt-10 text-sm text-muted">
            Sift, 2g per 70ml, whisk in an M until the foam is even. No timer needed.
          </p>
        )}
      </div>
    </main>
  );
}
