import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { TeaCard } from "@/components/tea-card";
import { KIND_LABEL, TEAS, type TeaKind } from "@/lib/catalog";
import { useFavorites } from "@/lib/favorites";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/collection/")({ component: CollectionPage });

const FILTERS: Array<{ id: "all" | "saved" | TeaKind; label: string }> = [
  { id: "all", label: "All" },
  { id: "green", label: KIND_LABEL.green },
  { id: "oxidized", label: KIND_LABEL.oxidized },
  { id: "roasted", label: KIND_LABEL.roasted },
  { id: "powder", label: KIND_LABEL.powder },
  { id: "saved", label: "Cellar" },
];

function CollectionPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const saved = useFavorites((s) => s.ids);

  const teas = useMemo(() => {
    if (filter === "all") return TEAS;
    if (filter === "saved") return TEAS.filter((t) => saved.includes(t.id));
    return TEAS.filter((t) => t.kind === filter);
  }, [filter, saved]);

  return (
    <main className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">Cellar</p>
      <h1 className="mt-2 font-display text-4xl text-foreground">The collection</h1>
      <p className="mt-3 max-w-xl text-muted">
        Six lots this season. Save a tea to your cellar — it stays on this device — and open any leaf for steeping notes.
      </p>

      <div className="mt-8 flex gap-2 overflow-x-auto pb-2">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "h-11 shrink-0 rounded-full px-4 text-sm transition-colors duration-150",
              filter === f.id
                ? "bg-primary text-primary-foreground"
                : "bg-surface text-foreground shadow-[var(--shadow-border)]",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {teas.length === 0 ? (
        <p className="mt-16 text-sm text-muted">Nothing saved yet. Heart a tea to keep it here.</p>
      ) : (
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {teas.map((tea) => (
            <TeaCard key={tea.id} tea={tea} />
          ))}
        </div>
      )}
    </main>
  );
}
