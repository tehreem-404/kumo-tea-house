import { createFileRoute, Link } from "@tanstack/react-router";
import { JOURNAL } from "@/lib/catalog";

export const Route = createFileRoute("/journal")({ component: JournalIndex });

function JournalIndex() {
  return (
    <main className="mx-auto max-w-6xl px-5 py-14 sm:px-8">
      <div className="grid gap-10 lg:grid-cols-[1.1fr_0.9fr] lg:items-end">
        <div>
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">Notes</p>
          <h1 className="mt-2 font-display text-4xl text-foreground">The house journal</h1>
          <p className="mt-3 max-w-xl text-muted">
            Short pieces on harvest, water, and the room. Written between seatings.
          </p>
        </div>
        <img
          src="/images/journal.jpg"
          alt="An open journal beside a teacup and dried camellia"
          className="aspect-[3/2] w-full rounded-2xl object-cover"
        />
      </div>
      <ul className="mt-14 divide-y divide-border border-y border-border">
        {JOURNAL.map((entry) => (
          <li key={entry.slug} className="py-8">
            <p className="text-xs text-subtle">{entry.date}</p>
            <h2 className="mt-2 font-display text-2xl text-foreground">
              <Link
                to="/journal/$slug"
                params={{ slug: entry.slug }}
                className="hover:underline underline-offset-4"
              >
                {entry.title}
              </Link>
            </h2>
            <p className="mt-2 max-w-2xl text-sm text-muted">{entry.excerpt}</p>
          </li>
        ))}
      </ul>
    </main>
  );
}
