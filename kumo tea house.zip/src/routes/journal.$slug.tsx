import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { JOURNAL } from "@/lib/catalog";

export const Route = createFileRoute("/journal/$slug")({
  component: JournalEntry,
  loader: ({ params }) => {
    const entry = JOURNAL.find((j) => j.slug === params.slug);
    if (!entry) throw notFound();
    return { entry };
  },
});

function JournalEntry() {
  const { entry } = Route.useLoaderData();

  return (
    <main className="mx-auto max-w-2xl px-5 py-14 sm:px-8">
      <Link
        to="/journal"
        className="inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-foreground"
      >
        <ArrowLeft className="size-4" />
        Journal
      </Link>
      <p className="mt-8 text-xs text-subtle">{entry.date}</p>
      <h1 className="mt-2 font-display text-4xl text-foreground">{entry.title}</h1>
      <div className="mt-8 space-y-5 text-base leading-relaxed text-muted">
        {entry.body.split("\n\n").map((para) => (
          <p key={para.slice(0, 24)}>{para}</p>
        ))}
      </div>
    </main>
  );
}
