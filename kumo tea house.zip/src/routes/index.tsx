import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { TeaCard } from "@/components/tea-card";
import { Button } from "@/components/ui/button";
import { TEAS } from "@/lib/catalog";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const featured = TEAS.filter((t) => t.featured);

  return (
    <main>
      <section className="relative min-h-[78vh] overflow-hidden">
        <img
          src="/images/hero.jpg"
          alt="Tea poured from a celadon pot into a small cup"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/55 to-bg/10" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-5 pb-16 pt-28 sm:px-8">
          <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted">Franklin Street · est. 2019</p>
          <h1 className="mt-3 max-w-xl font-display text-5xl leading-[1.05] tracking-tight text-foreground sm:text-6xl">
            A kettle, a room, and the length of a good minute.
          </h1>
          <p className="mt-5 max-w-md text-base text-muted">
            Kumo is a tea house of six seats and a seasonal cellar. We steep what the gardens send, nothing more.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <Link to="/collection">
                See the collection
                <ArrowRight className="size-4" />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link to="/ceremony">Book a ceremony</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">This season</p>
            <h2 className="mt-2 font-display text-3xl text-foreground">On the counter</h2>
          </div>
          <Link
            to="/collection"
            className="hidden text-sm text-primary underline-offset-4 hover:underline sm:inline"
          >
            Full cellar
          </Link>
        </div>
        <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((tea) => (
            <TeaCard key={tea.id} tea={tea} />
          ))}
        </div>
      </section>

      <section className="border-y border-border bg-surface">
        <div className="mx-auto grid max-w-6xl gap-10 px-5 py-20 lg:grid-cols-2 lg:items-center sm:px-8">
          <img
            src="/images/interior.jpg"
            alt="The tea house interior with paper screens and a hanging lantern"
            className="aspect-[16/10] w-full rounded-2xl object-cover"
          />
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">The room</p>
            <h2 className="mt-2 font-display text-3xl text-foreground">Eight tatami and a maple in the court.</h2>
            <p className="mt-4 text-base text-muted">
              The back room holds a single seating at a time. Phones rest in a cedar box. Forty minutes, a pot, and
              whatever light the afternoon decides to give.
            </p>
            <Button asChild className="mt-8">
              <Link to="/ceremony">
                Reserve a seat
                <ArrowRight className="size-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-20 sm:px-8">
        <p className="text-xs font-medium uppercase tracking-[0.2em] text-subtle">Hours</p>
        <div className="mt-6 grid gap-8 sm:grid-cols-3">
          {[
            { k: "Counter", v: "Daily, 11am–7pm. Walk-ins for steeping at the bar." },
            { k: "Ceremony", v: "Thursday–Sunday, by reservation. Forty minutes, six seats." },
            { k: "Address", v: "18 Franklin Street. The lantern is on after dusk." },
          ].map((item) => (
            <div key={item.k}>
              <h3 className="font-display text-xl text-foreground">{item.k}</h3>
              <p className="mt-2 text-sm text-muted">{item.v}</p>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
