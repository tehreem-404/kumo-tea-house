import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="mx-auto flex min-h-[50vh] max-w-xl flex-col items-center justify-center px-5 text-center">
      <h1 className="font-display text-3xl text-foreground">Page not found</h1>
      <p className="mt-3 text-sm text-muted">That path is not in the house. Return to the counter.</p>
      <a href="/" className="mt-6 text-sm text-primary underline-offset-4 hover:underline">
        Back home
      </a>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
  });
}
