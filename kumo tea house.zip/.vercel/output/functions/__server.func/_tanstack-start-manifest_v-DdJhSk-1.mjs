//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DdJhSk-1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/ceremony",
			"/collection",
			"/journal"
		],
		preloads: [
			"/assets/index-XKKvcuIf.js",
			"/assets/jsx-runtime-Cltr0gcK.js",
			"/assets/catalog-C6eU1Suu.js",
			"/assets/matchContext-BNcrmMbK.js",
			"/assets/useStore-DtQQzqbU.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-XKKvcuIf.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-AXQFym2n.js", "/assets/tea-card-CyTINpcZ.js"]
	},
	"/ceremony": {
		filePath: "/workspace/src/routes/ceremony.tsx",
		children: void 0,
		preloads: ["/assets/ceremony-CMLhq-Rk.js"]
	},
	"/collection": {
		filePath: "/workspace/src/routes/collection.tsx",
		children: ["/collection/$id", "/collection/"],
		preloads: ["/assets/collection-qPTCV0WJ.js"]
	},
	"/journal": {
		filePath: "/workspace/src/routes/journal.tsx",
		children: ["/journal/$slug"],
		preloads: ["/assets/journal-vHf5rZXw.js"]
	},
	"/collection/$id": {
		filePath: "/workspace/src/routes/collection.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/collection._id-TiIxWj0H.js",
			"/assets/arrow-left-NLCtgbpd.js",
			"/assets/heart-ClPv88I5.js"
		]
	},
	"/journal/$slug": {
		filePath: "/workspace/src/routes/journal.$slug.tsx",
		children: void 0,
		preloads: ["/assets/journal._slug-TBvQM-Se.js", "/assets/arrow-left-NLCtgbpd.js"]
	},
	"/collection/": {
		filePath: "/workspace/src/routes/collection.index.tsx",
		children: void 0,
		preloads: ["/assets/collection.index-CRXDEpYr.js", "/assets/tea-card-CyTINpcZ.js"]
	}
} });
//#endregion
export { tsrStartManifest };
