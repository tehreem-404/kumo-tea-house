import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Pause, i as Play, l as ArrowLeft, r as RotateCcw, s as Heart } from "../_libs/lucide-react.mjs";
import { a as Button, i as useFavorites, l as cn, r as Route$1, s as KIND_LABEL } from "./router-CFbTXbn4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/collection._id-BNr6OxbS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SteepTimer({ minutes }) {
	const total = Math.max(1, Math.round(minutes * 60));
	const [left, setLeft] = (0, import_react.useState)(total);
	const [running, setRunning] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		setLeft(total);
		setRunning(false);
	}, [total]);
	(0, import_react.useEffect)(() => {
		if (!running) return;
		const id = window.setInterval(() => {
			setLeft((s) => {
				if (s <= 1) {
					setRunning(false);
					return 0;
				}
				return s - 1;
			});
		}, 1e3);
		return () => window.clearInterval(id);
	}, [running]);
	const m = Math.floor(left / 60);
	const s = left % 60;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-center gap-3 rounded-2xl bg-surface p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "font-display text-3xl tabular-nums tracking-tight text-foreground",
			children: [
				m,
				":",
				s.toString().padStart(2, "0")
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: running ? "outline" : "default",
				onClick: () => setRunning((v) => !v),
				disabled: left === 0 && !running,
				children: [running ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }), running ? "Pause" : "Steep"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: () => {
					setLeft(total);
					setRunning(false);
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
			})]
		})]
	});
}
function TeaDetail() {
	const { tea } = Route$1.useLoaderData();
	const has = useFavorites((s) => s.ids.includes(tea.id));
	const toggle = useFavorites((s) => s.toggle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto grid max-w-6xl gap-10 px-5 py-14 lg:grid-cols-2 lg:items-start sm:px-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: tea.image,
			alt: tea.name,
			className: "aspect-square w-full rounded-2xl object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/collection",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Collection"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 text-xs font-medium uppercase tracking-[0.2em] text-subtle",
				children: [
					KIND_LABEL[tea.kind],
					" · ",
					tea.origin
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl text-foreground",
				children: tea.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-base text-muted",
				children: tea.notes
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 grid grid-cols-2 gap-4 text-sm sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-subtle",
						children: "Harvest"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 text-foreground",
						children: tea.harvest
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-subtle",
						children: "Water"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
						className: "mt-1 tabular-nums text-foreground",
						children: [tea.steepC, "°C"]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-subtle",
						children: "Time"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 tabular-nums text-foreground",
						children: tea.steepMin === 0 ? "Whisk" : `${tea.steepMin} min`
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-6 font-display text-2xl tabular-nums text-foreground",
				children: ["$", tea.price]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex flex-wrap gap-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: has ? "outline" : "default",
					onClick: () => toggle(tea.id),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-4", has && "fill-current") }), has ? "In your cellar" : "Save to cellar"]
				})
			}),
			tea.steepMin > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl text-foreground",
						children: "Steep timer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 mb-4 text-sm text-muted",
						children: "Set for the first infusion. Reset between cups."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SteepTimer, { minutes: tea.steepMin })
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 text-sm text-muted",
				children: "Sift, 2g per 70ml, whisk in an M until the foam is even. No timer needed."
			})
		] })]
	});
}
//#endregion
export { TeaDetail as component };
