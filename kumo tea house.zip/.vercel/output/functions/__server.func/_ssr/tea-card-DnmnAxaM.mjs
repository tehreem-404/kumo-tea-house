import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as Heart } from "../_libs/lucide-react.mjs";
import { i as useFavorites, l as cn, s as KIND_LABEL } from "./router-CFbTXbn4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tea-card-DnmnAxaM.js
var import_jsx_runtime = require_jsx_runtime();
function TeaCard({ tea }) {
	const has = useFavorites((s) => s.ids.includes(tea.id));
	const toggle = useFavorites((s) => s.toggle);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex flex-col overflow-hidden rounded-2xl bg-surface shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-250 hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/collection/$id",
			params: { id: tea.id },
			className: "relative block aspect-square overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: tea.image,
				alt: tea.name,
				className: "size-full object-cover transition-transform duration-400 group-hover:scale-[1.03]"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-medium uppercase tracking-wider text-subtle",
						children: [
							KIND_LABEL[tea.kind],
							" · ",
							tea.origin
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-xl text-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/collection/$id",
							params: { id: tea.id },
							children: tea.name
						})
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": has ? "Remove from cellar" : "Save to cellar",
						"aria-pressed": has,
						className: "relative flex size-11 shrink-0 items-center justify-center rounded-lg",
						onClick: () => toggle(tea.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, { className: cn("size-5", has ? "fill-primary text-primary" : "text-muted") })
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: tea.notes
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-auto pt-2 text-sm tabular-nums text-foreground",
					children: ["$", tea.price]
				})
			]
		})]
	});
}
//#endregion
export { TeaCard as t };
