import { _ as Link, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { l as ArrowLeft } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-CFbTXbn4.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/journal._slug-aWNQpwwJ.js
var import_jsx_runtime = require_jsx_runtime();
function JournalEntry() {
	const { entry } = Route.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-2xl px-5 py-14 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/journal",
				className: "inline-flex h-11 items-center gap-2 text-sm text-muted hover:text-foreground",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Journal"]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-8 text-xs text-subtle",
				children: entry.date
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl text-foreground",
				children: entry.title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 space-y-5 text-base leading-relaxed text-muted",
				children: entry.body.split("\n\n").map((para) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: para }, para.slice(0, 24)))
			})
		]
	});
}
//#endregion
export { JournalEntry as component };
