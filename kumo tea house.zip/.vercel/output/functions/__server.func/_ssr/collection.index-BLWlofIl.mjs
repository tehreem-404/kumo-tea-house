import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as TEAS, i as useFavorites, l as cn, s as KIND_LABEL } from "./router-CFbTXbn4.mjs";
import { t as TeaCard } from "./tea-card-DnmnAxaM.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/collection.index-BLWlofIl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "green",
		label: KIND_LABEL.green
	},
	{
		id: "oxidized",
		label: KIND_LABEL.oxidized
	},
	{
		id: "roasted",
		label: KIND_LABEL.roasted
	},
	{
		id: "powder",
		label: KIND_LABEL.powder
	},
	{
		id: "saved",
		label: "Cellar"
	}
];
function CollectionPage() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const saved = useFavorites((s) => s.ids);
	const teas = (0, import_react.useMemo)(() => {
		if (filter === "all") return TEAS;
		if (filter === "saved") return TEAS.filter((t) => saved.includes(t.id));
		return TEAS.filter((t) => t.kind === filter);
	}, [filter, saved]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto max-w-6xl px-5 py-14 sm:px-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.2em] text-subtle",
				children: "Cellar"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl text-foreground",
				children: "The collection"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-muted",
				children: "Six lots this season. Save a tea to your cellar — it stays on this device — and open any leaf for steeping notes."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 flex gap-2 overflow-x-auto pb-2",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("h-11 shrink-0 rounded-full px-4 text-sm transition-colors duration-150", filter === f.id ? "bg-primary text-primary-foreground" : "bg-surface text-foreground shadow-[var(--shadow-border)]"),
					children: f.label
				}, f.id))
			}),
			teas.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-16 text-sm text-muted",
				children: "Nothing saved yet. Heart a tea to keep it here."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: teas.map((tea) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeaCard, { tea }, tea.id))
			})
		]
	});
}
//#endregion
export { CollectionPage as component };
